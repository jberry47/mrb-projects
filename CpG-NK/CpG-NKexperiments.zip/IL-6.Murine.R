library(plyr)
library(ggplot2)
library(car)
library(reshape2)
library(scales)
library(lme4)
library(stringr)
library(grid)
library(gridExtra)
library(lsmeans)
library(ggbeeswarm)
library(ggpubr)

CpG <- read.csv("Line.plots.csv",header = T,stringsAsFactors = F)
CpG$Treatment <- ordered(CpG$Treatment,levels=c("CpG ODN 2395"))
head(CpG)


p <- ggplot(CpG[CpG$Treatment],aes(Concentration,Value))+
  geom_point(aes(color=Name,size=SEM))+
  geom_line(aes(color=Name))+
  scale_x_log10()+
  theme_light()+
  ylab("IL-6 (pg/mL)")+
  xlab("nM")+
  theme(plot.title = element_text(hjust = 0.5))+
  theme(axis.text = element_text(size = 14),
        plot.title = element_text(size = 20),
        axis.title= element_text(size = 18))+
  theme(strip.background=element_rect(fill="gray50"),
        strip.text.x=element_text(size=14,color="white"),
        strip.text.y=element_text(size=14,color="white"))+
  theme(legend.text = element_text(size = 14),
        legend.title = element_text(size = 14))
p
ggsave("IL-6.line.plot.png",plot=p,width=4,height = 4.5,dpi = 300)
